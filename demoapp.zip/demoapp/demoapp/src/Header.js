import React, {Component} from 'react';
import {Navbar, Nav} from 'react-bootstrap';
import Button from '@material-ui/core/Button';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';

class Header extends Component{
    render(){ 
        return (
        <AppBar position="static">
        <Toolbar>
          <IconButton edge="start"  color="inherit">
            <MenuIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
            
        )
    }
}

export default Header