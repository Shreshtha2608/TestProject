import React, {Component} from 'react'
import logo from './logo.svg'
import './App.css'
import Header from './Header'
import Footer from './Footer'
import Content from './Content'
import Sidebar from './Sidebar'
import 'bootstrap/dist/css/bootstrap.min.css';
import { sizing } from '@material-ui/system';

class App extends Component{
  render(){
  return (
    <div className="App">
      <Header></Header>
      <Content></Content>
      
      <Footer></Footer>
    </div>
  );
  }
}

export default App;
