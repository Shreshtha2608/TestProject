import React, {Component} from 'react';
import {navbar, nav} from 'react-bootstrap';
import List from '@material-ui/core/List'
import Button from  '@material-ui/core/Button'
import ListItem from '@material-ui/core/ListItem'
import ListItemText from '@material-ui/core/ListItemText'
import { sizing } from '@material-ui/system';
import Box from '@material-ui/core/Box';

class Newdiv extends Component {
    render(){
        <TableRow>
            <TableCell>
                <Checkbox/> AAA
            </TableCell>
         </TableRow>
    }
  }
  
  export default Newdiv