import React, {Component} from 'react';
import {Navbar, Nav} from 'react-bootstrap';

class Footer extends Component{
    render(){
        return (
            <Navbar bg="light" variant="light">
                <Navbar.Brand href="#" className="text-right">Appi LTD 2019</Navbar.Brand>
                <Navbar.Brand href="#" >Privacy</Navbar.Brand>
                <Navbar.Brand href="#" >Terms of Use</Navbar.Brand>
                <Navbar.Brand href="#" >Cookies</Navbar.Brand>
            </Navbar>
        )
    }
}

export default Footer