import React, {Component} from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Toolbar from '@material-ui/core/Toolbar';
import Checkbox from '@material-ui/core/Checkbox';
import IconButton from '@material-ui/core/IconButton';
import List from '@material-ui/core/List'
import Button from  '@material-ui/core/Button'
import ListItem from '@material-ui/core/ListItem'
import ListItemText from '@material-ui/core/ListItemText'
import { sizing } from '@material-ui/system';
import Box from '@material-ui/core/Box';
import Container from '@material-ui/core/Container';
import Grid from '@material-ui/core/Grid';
import Sidebar from './Sidebar'
import TextField from '@material-ui/core/TextField';
import SearchIcon from '@material-ui/icons/Search';
import AppBar from '@material-ui/core/AppBar';


class Content extends Component{
    constructor() {
        super();
        this.state = {isChecked: false};
        
    }
    
    handleChecked = (e) => {
        this.setState({isChecked: !this.state.isChecked});
        console.log(this.state.isChecked);
      }
    render(){
        let ss;
        if(this.state.isChecked){
            ss = <Sidebar></Sidebar>
            console.log(this.state.isChecked);
         } 
        return (
        <Grid container direction="row" spacing={4}>
        <Grid item xs={4}>
            <List >
                <ListItem>
                    <ListItemText><button variant="contained" color="primary">Add Candidate</button></ListItemText>
                </ListItem>
                <ListItem button>
                    <ListItemText>Candidates</ListItemText>
                </ListItem>
                <ListItem button>
                    <ListItemText>Work Pass Checks</ListItemText>
                </ListItem>
                <ListItem button>
                    <ListItemText>Organisations</ListItemText>
                </ListItem>
                <ListItem button>
                    <ListItemText>Payments</ListItemText>
                </ListItem>
            </List>
        </Grid>
        <Grid item xs={8}>
            <Box m={2} float="left">
            <button>Work Pass Administration</button>
            <button>Guidant Global</button>
            </Box>
            <AppBar position="static">
        <Toolbar>
                Company
                <Box ml={4}>
                    <button m={2}>ADD</button>
                    <button>REMOVE</button>
                </Box>
                <Box ml={10}>
                Persons
                        <button>NEW</button>
                        <button>REMOVE</button>
                        <button>Checks</button>
                </Box>
                </Toolbar>
      </AppBar>
            <Grid container direction="row">
                <Grid item xs={6}>
                <TextField label="Search" variant="outlined"  />
                    <Table>
                        <TableBody>
                            <TableRow>
                                <TableCell>
                                    <Checkbox onClick={ this.handleChecked }/>British Airways
                                </TableCell>
                            </TableRow>
                            <TableRow>
                                <TableCell>
                                    <Checkbox/> AAA
                                </TableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                </Grid>
                <Grid item xs={6}>
                    {ss}
                </Grid>
            </Grid>
            </Grid>
            </Grid>
        )
    }
}

export default Content