import React, {Component} from 'react';
import { sizing } from '@material-ui/system';
import Box from '@material-ui/core/Box';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Checkbox from '@material-ui/core/Checkbox';
import TextField from '@material-ui/core/TextField';
import SearchIcon from '@material-ui/icons/Search';


  function Sidebar(){
    return(
        <div>
        <TextField label="Search" variant="outlined" m={3}  />
        <Table>    
        <TableBody>
        <TableRow>
            <TableCell>
                 <Checkbox/>Permanent Ops Cargo Driver Airside
            </TableCell>
        </TableRow>
            <TableRow>
                <TableCell>
                    <Checkbox/> Cargo Warehouse Airside
                </TableCell>
            </TableRow>
        </TableBody>
        </Table>
        </div>
    )
  }
  export default Sidebar